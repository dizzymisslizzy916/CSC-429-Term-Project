package model;

import exception.InvalidPrimaryKeyException;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;


public class Shift extends EntityBase {
    private static final String myTableName = "Shift";

    private String updateStatusMessage = "";


    public Shift(String scoutId, String sessionId) throws InvalidPrimaryKeyException {
        super(myTableName);

        String query = String.format(
                "SELECT * FROM %1$s WHERE (ScoutID = %2$s) AND (SessionID = %3$s)",
                myTableName, scoutId, sessionId);

        Vector<Properties> allDataRetrieved = getSelectQueryResult(query);

        if (allDataRetrieved != null) {
            int size = allDataRetrieved.size();

            if (size != 1) {
                throw new InvalidPrimaryKeyException("");
            }
            else {
                // Copy all retrived data into persistent state.
                Properties retrievedScoutData = allDataRetrieved.elementAt(0);
                persistentState = new Properties();
                Enumeration allKeys = retrievedScoutData.propertyNames();
                while (allKeys.hasMoreElements()) {
                    String nextKey = (String) allKeys.nextElement();
                    String nextValue = retrievedScoutData.getProperty(nextKey);
                    if (nextValue != null) {
                        persistentState.setProperty(nextKey, nextValue);
                    }
                }
            }
        }
        else {
            throw new InvalidPrimaryKeyException("");
        }
    }


    public Shift(Properties props) {
        super(myTableName);

        persistentState = new Properties();

        Enumeration allKeys = props.propertyNames();
        while (allKeys.hasMoreElements()) {
            String nextKey = (String) allKeys.nextElement();
            String nextValue = props.getProperty(nextKey);

            if (nextValue != null) {
                persistentState.setProperty(nextKey, nextValue);
            }
        }

    }


    public void update() {
        if (persistentState.getProperty("ID") != null) { // Update Existing
            try {
                Properties whereClause = new Properties();

                whereClause.setProperty("ID", persistentState.getProperty("ID"));

                updatePersistentState(mySchema, persistentState, whereClause);

            } catch (SQLException ex) {
            }
        }
        else { // Insert New
            try {
                Integer shiftId = insertAutoIncrementalPersistentState(mySchema, persistentState);
                persistentState.setProperty("ID", shiftId.toString());

            } catch (SQLException ex) {
            }
        }
    }


    public Object getState(String key) {
        if (key.equals("UpdateStatusMessage"))
            return updateStatusMessage;

        return persistentState.getProperty(key);
    }


    public void stateChangeRequest(String key, Object value) {
        if (persistentState.containsKey(key))
            persistentState.setProperty(key, (String)value);

        myRegistry.updateSubscribers(key, this);
    }


    protected void initializeSchema(String tableName) {
        if (mySchema == null) {
            mySchema = getSchemaInfo(tableName);
        }
    }

}
