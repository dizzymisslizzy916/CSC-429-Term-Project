package model;

import java.time.LocalDateTime;
import java.util.Properties;
import javafx.scene.Scene;
import userinterface.View;
import userinterface.ViewFactory;


public class StartSessionTransaction extends Transaction {
    LocalDateTime currentDateTime = LocalDateTime.now();
    String updateStatusMessage = "";
    private String transactionErrorMessage = "";
    String sessionId = "";
    String selectedScoutId = "";
    ScoutCollection scoutSearchResults = new ScoutCollection();
    ScoutCollection scoutsOnShift = new ScoutCollection();

    public StartSessionTransaction() throws Exception{
        super();
    }

    
    protected void setDependencies() {
        Properties dependencies = new Properties();

        dependencies.put("SubmitSession", "OpenSessionId,TransactionError,UpdateStatusMessage");
        dependencies.put("SearchScouts", "SearchResults");
        dependencies.put("SelectScout", "SelectedScout,TransactionError,UpdateStatusMessage");
        dependencies.put("SubmitShift", "ScoutsOnShift,TransactionError,UpdateStatusMessage");
        dependencies.put("Done", "CancelTransaction,OpenSessionId");
        myRegistry.setDependencies(dependencies);
    }

    
    protected void getMessagesBundle() {

    }

    
    protected Scene createView() {
        Scene currentScene = myViews.get("SessionInfoView");

        if (currentScene == null) {
            View newView = ViewFactory.createView("SessionInfoView", this);
            currentScene = new Scene(newView);
            myViews.put("SessionInfoView", currentScene);
        }



        return currentScene;
    }

    protected void createAndShowNewShiftView() {
        Scene currentScene = myViews.get("OpenShiftLookupView");

        if (currentScene == null) {
            View newView = ViewFactory.createView("OpenShiftLookupView", this);
            currentScene = new Scene(newView);
            myViews.put("OpenShiftLookupView", currentScene);

            Properties p = new Properties();
            p.setProperty("FirstName", "");
            p.setProperty("LastName", "");
            stateChangeRequest("SearchScouts", p);
        }



        swapToView(currentScene);
    }

    protected void createAndShowShiftFormView() {
        Scene currentScene = myViews.get("OpenShiftFormView");

        if (currentScene == null) {
            View newView = ViewFactory.createView("OpenShiftFormView", this);
            currentScene = new Scene(newView);
            myViews.put("OpenShiftFormView", currentScene);
        }



        swapToView(currentScene);
    }

    
    public void stateChangeRequest(String key, Object value) {
        switch (key) {
            case "DoYourJob":
                doYourJob();
                break;

            case "SubmitSession":
                createNewSession((Properties)value);
                break;

            case "SearchScouts":
                searchScouts((Properties)value);
                break;

            case "SelectScout":
                selectedScoutId = (String)value;
                if (scoutsOnShift.retrieve(selectedScoutId) != null) {
                    updateStatusMessage = "Scout already added to session!";
                }
                else {
                    createAndShowShiftFormView();
                }
                break;

            case "SubmitShift":
                submitShift((Properties)value);
                break;

            case "Back":
                createAndShowNewShiftView();
                break;

            case "Done":
                break;
        }

        myRegistry.updateSubscribers(key, this);
    }

    void createNewSession(Properties p) {
        updateStatusMessage = "";
        transactionErrorMessage = "";

        Session newSession = new Session(p);
        newSession.update();

        sessionId = (String) newSession.getState("ID");
        updateStatusMessage = (String) newSession.getState("UpdateStatusMessage");
        transactionErrorMessage = updateStatusMessage;

        if ((sessionId != null) && (!"".equals(sessionId))) {
            createAndShowNewShiftView();
        }
    }

    private void searchScouts(Properties searchTerms) {
        String firstName = searchTerms.getProperty("FirstName");
        String lastName = searchTerms.getProperty("LastName");

        scoutSearchResults = new ScoutCollection();

        try {
            scoutSearchResults.lookupScoutsByName(firstName, lastName);
        } catch (Exception e) {
            updateStatusMessage = e.getMessage();
            transactionErrorMessage = updateStatusMessage;
        }
    }

    void submitShift(Properties p) {
        updateStatusMessage = "";
        transactionErrorMessage = "";

        p.setProperty("SessionID", sessionId);
        p.setProperty("ScoutID", selectedScoutId);

        Shift newShift = new Shift(p);
        newShift.update();
        updateStatusMessage = (String) newShift.getState("UpdateStatusMessage");
        transactionErrorMessage = updateStatusMessage;

        String shiftId = (String) newShift.getState("ID");
        if ((sessionId != null) && (!"".equals(sessionId))) {
            scoutsOnShift.addScout(scoutSearchResults.retrieve(selectedScoutId));
            createAndShowNewShiftView();
        }
    }


    
    public Object getState(String key) {
        switch (key) {
            case "CurrentDateTime":
                return currentDateTime;

            case "OpenSessionId":
                return sessionId;

            case "SearchResults":
                return scoutSearchResults.getState("Scouts");

            case "SelectedScout":
                return scoutSearchResults.retrieve(selectedScoutId);

            case "ScoutsOnShift":
                return scoutsOnShift.getState("Scouts");

            case "UpdateStatusMessage":
                return updateStatusMessage;

            case "TransactionErrorMessage":
                return transactionErrorMessage;

            default:
                return null;
        }
    }

}