// specify the package
package model;

// system imports
import exception.InvalidPrimaryKeyException;
import javafx.scene.Scene;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;


// project imports
import event.Event;

import userinterface.View;
import userinterface.ViewFactory;

/** The class containing the WithdrawTransaction for the ATM application */
//==============================================================
public class SellTreeTransaction extends Transaction
{
    private TreeTransaction selectedTrans; // needed for GUI only
    private Tree selectedTree;
    private Session selectedSession;

    private String transactionErrorMessage = "";
    private TreeCollection treeCollection;
    private String treeSellMessage = "";

    public SellTreeTransaction() throws Exception//constructor
    {
        super();
        System.out.println("test1");
        treeCollection = new TreeCollection();
        System.out.println("test2");
        selectedSession = new Session();
        try {
            selectedSession.findOpenSession();
        } catch(InvalidPrimaryKeyException e) {
            e.printStackTrace();
            transactionErrorMessage = "ERROR: No Open Session Found";
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    protected void setDependencies()
    {
        dependencies = new Properties();
        dependencies.setProperty("TreeData", "TransactionError");
        dependencies.setProperty("OK", "CancelTransaction");
        dependencies.setProperty("SellTree","TreeSellMessage");
        dependencies.setProperty("CancelSearchTrees","CancelTransaction");

        myRegistry.setDependencies(dependencies);
    }

    public void processTreeBarcode(String barcode) {
        try {
            System.out.println("model/SellTreeTransactionMethod: processTreeBarcode is running");
            System.out.println(barcode);
            selectedTree = new Tree(barcode);
            String status = selectedTree.persistentState.getProperty("Status");
            if(status.equals("Sold")) {
                transactionErrorMessage = "ERROR: Tree already sold";
                stateChangeRequest("TransactionError", null);
                return;
            }

            Properties transactionProperties = new Properties();
            transactionProperties.setProperty("barCode", barcode);
            selectedTrans = new TreeTransaction(transactionProperties);

            System.out.println("HERE");
            createAndShowCostScreenView();

        }catch (Exception ex){
            transactionErrorMessage = "ERROR: Could not find tree with barcode: " + barcode;
            stateChangeRequest("TransactionError", null);
            new Event(Event.getLeafLevelClassName(this), "processTransaction",
                    "Failed to retrieve a tree.",
                    Event.ERROR);

        }
    }

    public void processTransaction(Properties props) {
        String payMethod = props.getProperty("paymentMethod");
        selectedTrans.persistentState.setProperty("paymentMethod", payMethod);
        selectedTrans.persistentState.setProperty("transactionType", "Tree Sale");
        String name = props.getProperty("customerName");
        selectedTrans.persistentState.setProperty("customerName", name);
        String phoneNum = props.getProperty("customerPhone");
        selectedTrans.persistentState.setProperty("customerPhone", phoneNum);
        String email = props.getProperty("customerEmail");
        selectedTrans.persistentState.setProperty("customerEmail", email);
        selectedTrans.persistentState.setProperty("sessionId", (String) selectedSession.getState("Id"));
        DateFormat timeStamp = new SimpleDateFormat("yyyy/MM/dd_hh:mm a");
        Date date = new Date();
        System.out.println(timeStamp.format(date));
        String[] dateTime = timeStamp.format(date).split("_");
        selectedTrans.persistentState.setProperty("transactionDate", dateTime[0]);
        //TODO - maybe wrong?
        selectedTrans.persistentState.setProperty("dateStatusUpdate", dateTime[0]);
        selectedTrans.persistentState.setProperty("transactionTime", dateTime[1]);


        System.out.println(payMethod);
        selectedTree.persistentState.setProperty("Status", "Sold");
        selectedTree.update();
        selectedTrans.update();

        treeSellMessage = "Tree sold successfully!";
    }

    public void processNewCost(Properties props) {

        //Take in new cost entered
        selectedTrans.persistentState.setProperty("transactionAmount", props.getProperty("Cost"));



    }

    public Object getState(String key)
    {
        if (key.equals("TransactionError") == true)
        {
            System.out.println("test 101: " + transactionErrorMessage);
            return transactionErrorMessage;
        }
   /* else
    if (key.equals("SellStatusMessage") == true)
    {
     return transactionErrorMessage;*/
        else if (key.equals("TreeList") == true)
        {
            return treeCollection;
        }
        else if (key.equals("SelectedTree") == true) {
            return selectedTree;
        }
        else if (key.equals("treeType") == true) {
            String val = (String) selectedTree.getState(key);
            // TreeType tt = new TreeType();
            try {
                // tt.findWithTreeTypeId(val);
                //return tt.getState("typeDescription");
            } catch (Exception ex) {
                return "Description not found";
            }
        }
        else if (key.equals("TreeSellMessage") == true) {
            return treeSellMessage;
        }
        else if (selectedTree != null) {
            Object val = selectedTree.getState(key);
            if (val != null) {
                return val;
            }
        }


        return null;
    }

    public void stateChangeRequest(String key, Object value)
    {
        if (key.equals("DoYourJob") == true)
        {
            System.out.println("doyourjob");
            doYourJob();
        }
        else if (key.equals("TreeBarcodeEntered") == true)
        {
            processTreeBarcode((String)value);
        }
        else if (key.equals("TreeSelected") == true) {
            String barCode = (String)value;
            selectedTree = treeCollection.retrieve(barCode);
        }
        else if (key.equals("InsertTransaction") == true) {

            processTransaction((Properties)value);
        }
        else if (key.equals("NewCost") == true) {
            processNewCost((Properties)value);
            createAndShowCustomerInfoView();
        }

        myRegistry.updateSubscribers(key, this);
    }


    protected void createAndShowCustomerInfoView()
    {
        View v = ViewFactory.createView("CustomerInfoView", this);
        Scene newScene = new Scene(v);

        swapToView(newScene);
    }


    protected void createAndShowCostScreenView()
    {
        View v = ViewFactory.createView("CostScreenView", this);
        Scene newScene = new Scene(v);

        swapToView(newScene);
    }



    protected Scene createView()
    {
        Scene currentScene = myViews.get("TreeBarCodeEntryView");
        System.out.println("create the view");
        if (currentScene == null)
        {
            // create our new view
            View newView = ViewFactory.createView("TreeBarCodeEntryView", this);
            currentScene = new Scene(newView);
            myViews.put("TreeBarCodeEntryView", currentScene);

            return currentScene;
        }
        else
        {
            return currentScene;
        }
    }

//------------------------------------------------------

}