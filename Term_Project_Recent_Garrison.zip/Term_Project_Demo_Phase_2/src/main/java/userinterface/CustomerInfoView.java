package userinterface;

// system imports
import Utilities.UIUtils;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

import java.util.Properties;

// project imports
import impresario.IModel;

public class CustomerInfoView extends View{

    protected TextField customerName;
    protected TextField customerEmail;
    protected ComboBox paymentMethod;
    protected TextField customerPhone;


    protected Button submitButton;
    protected Button doneButton;
    private String statusMessage = "";

    // For showing error message
    protected MessageView statusLog;

    public CustomerInfoView(IModel wsc)
    {
        super(wsc, "UpdateTreeView");

        // create a container for showing the contents
        VBox container = new VBox(10);
        container.setPadding(new Insets(15, 5, 5, 5));

        // create our GUI components, add them to this panel
        container.getChildren().add(createTitle());
        container.getChildren().add(createFormContent());

        // Error message area
        container.getChildren().add(createStatusLog("                                            "));

        getChildren().add(container);


        myModel.subscribe("TransactionError", this);
        myModel.subscribe("TreeSellMessage", this);
        populateFields();
    }

    protected void populateFields()
    {

    }

    private Node createTitle()
    {
        HBox container = new HBox();
        container.setAlignment(Pos.CENTER);

        Text titleText = new Text(" TROOP 209 TREE SALES SYSTEM ");
        titleText.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titleText.setWrappingWidth(300);
        titleText.setTextAlignment(TextAlignment.CENTER);
        titleText.setFill(Color.BLACK);
        container.getChildren().add(titleText);

        return container;
    }

    private VBox createFormContent()
    {
        VBox vbox = new VBox(10);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Text prompt = new Text("Customer Info "); //add barcode here?
        prompt.setWrappingWidth(350);
        prompt.setTextAlignment(TextAlignment.CENTER);
        prompt.setFill(Color.BLACK);
        grid.add(prompt, 0, 0, 2, 1);

        //tree type
        Text customerNameLabel = new Text(" Customer Name : ");
        Font myFont = Font.font("Helvetica", FontWeight.BOLD, 12);
        customerNameLabel.setFont(myFont);
        customerNameLabel.setWrappingWidth(150);
        customerNameLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(customerNameLabel, 0, 1);

        customerName = new TextField();
        grid.add(customerName, 1, 1);

        //notes
        Text customerPhoneLabel = new Text(" Customer Phone : ");
        customerPhoneLabel.setFont(myFont);
        customerPhoneLabel.setWrappingWidth(150);
        customerPhoneLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(customerPhoneLabel, 0, 2);

        customerPhone = new TextField();
        grid.add(customerPhone, 1, 2);
        UIUtils.limitLength(customerPhone, 10);
        UIUtils.limitToDigits(customerPhone);

        Text customerEmailLabel = new Text(" Customer Email : ");
        customerEmailLabel.setFont(myFont);
        customerEmailLabel.setWrappingWidth(150);
        customerEmailLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(customerEmailLabel,0, 3);

        customerEmail = new TextField();
        grid.add(customerEmail, 1, 3);

        Text paymentMethodLabel = new Text(" Payment Method : ");
        paymentMethodLabel.setFont(myFont);
        paymentMethodLabel.setWrappingWidth(150);
        paymentMethodLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(paymentMethodLabel,0, 4);

        paymentMethod = new ComboBox<String>();
        String[] options = {"cash", "check"};
        paymentMethod.setItems(FXCollections.observableArrayList(options));
        paymentMethod.getSelectionModel().selectFirst();
        grid.add(paymentMethod, 1, 4);

        //Submit and Done button

        HBox doneCont = new HBox(10);
        doneCont.setAlignment(Pos.CENTER);

        submitButton = new Button("Submit");
        submitButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        submitButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                clearErrorMessage();

                Properties props = new Properties();

                String nameInput = customerName.getText();
                String phoneInput = customerPhone.getText();
                String emailInput = customerEmail.getText();
                String paymentInput = (String) paymentMethod.getValue();

                //Name length check
                if (nameInput.length() > 15 || nameInput.length() > 15) {
                    displayErrorMessage("ERROR: Name may not exceed 15 characters.");
                    return;
                }
                if(nameInput.equals("") && paymentInput.equals("check")) {
                    displayErrorMessage("ERROR: Check transactions require a name");
                    return;
                }

                //Phone Number Check

                if ((phoneInput == null) || (phoneInput.length() == 0)) {
                    displayErrorMessage("ERROR: Please enter a 10-digit phone number");
                    return;
                } else if (phoneInput.length() != 10) {
                    displayErrorMessage("ERROR: Please enter a 10-digit phone number");
                    return;
                } else {
                    try {
                        Long.parseLong(phoneInput);
                    } catch (Exception ex) {
                        displayErrorMessage("ERROR: Phone number must have only digits");
                        return;
                    }
                }

                //Email must contain @
                if ((emailInput == null) || (emailInput.length() == 0)) {
                    displayErrorMessage("ERROR: Please enter a valid email.");
                    return;
                } else if (!emailInput.contains("@")) {
                    displayErrorMessage("ERROR: Please enter a valid email");
                    return;
                }

                if(paymentInput == null) {
                    displayErrorMessage("ERROR: Please select a payment method");
                    return;
                }

                props.setProperty("customerName",nameInput);
                props.setProperty("customerPhone", phoneInput);
                props.setProperty("customerEmail", emailInput);
                props.setProperty("paymentMethod", paymentInput);


                //displayMessage("Tree Updated Successfully"); validation should come from model

                myModel.stateChangeRequest("InsertTransaction", props);
                Platform.runLater(() -> {
                    submitButton.setDisable(true);
                });

            }
        });
        doneCont.getChildren().add(submitButton);

        doneButton = new Button("Back");
        doneButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        doneButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                clearErrorMessage();
                myModel.stateChangeRequest("CancelTransaction", null);
            }
        });
        doneCont.getChildren().add(doneButton);

        vbox.getChildren().add(grid);
        vbox.getChildren().add(doneCont);

        return vbox;
    }

    // Create the status log field
    //-------------------------------------------------------------
    protected MessageView createStatusLog(String initialMessage)
    {
        statusLog = new MessageView(initialMessage);

        return statusLog;
    }

    //-------------------------------------------------------------

    /**
     * Update method
     */
    //---------------------------------------------------------
    public void updateState(String key, Object value)
    {

        if (key.equals("TransactionError") == true)
        {
            String val = (String)value;
            if ((val.startsWith("Err")) || (val.startsWith("ERR"))) {
                displayErrorMessage(val);
            }
            else {
                displayMessage(val);
            }
        }
        if (key.equals("StatusMessage") == true) {
            String val = (String) value;
            if ((val.startsWith("Err")) || (val.startsWith("ERR"))) {
                displayErrorMessage(val);
            } else {
                displayMessage(val);
            }
        }
    }

    /**
     * Display error message
     */
    //----------------------------------------------------------
    public void displayErrorMessage(String message)
    {
        statusLog.displayErrorMessage(message);
    }

    /**
     * Display info message
     */
    //----------------------------------------------------------
    public void displayMessage(String message)
    {
        statusLog.displayMessage(message);
    }

    /**
     * Clear error message
     */
    //----------------------------------------------------------
    public void clearErrorMessage()
    {
        statusLog.clearErrorMessage();
    }

}

//---------------------------------------------------------------
//	Revision History:
//



