package userinterface;

public class TreeTypeCollectionView {
}
