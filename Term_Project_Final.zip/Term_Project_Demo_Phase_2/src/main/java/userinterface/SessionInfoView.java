package userinterface;

// system imports
import Utilities.UIUtils;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.Vector;
import java.util.Enumeration;

// project imports
import impresario.IModel;
import javafx.util.StringConverter;
import model.*;



public class SessionInfoView extends View{
    protected DatePicker startDate;
    protected TextField startTime;
    protected TextField endTime;
    protected TextField startCash;
    protected Button submitButton;
    protected Button doneButton;

    // For showing error message
    protected MessageView statusLog;


    public SessionInfoView(IModel session)
    {
        super(session, "SessionInfoView");

        // create a container for showing the contents
        VBox container = new VBox(10);
        container.setPadding(new Insets(15, 5, 5, 5));

        // Add a title for this panel
        container.getChildren().add(createTitle());

        // create our GUI components, add them to this Container
        container.getChildren().add(createFormContent());

        container.getChildren().add(createStatusLog("             "));

        getChildren().add(container);

        populateFields();

        myModel.subscribe("UpdateStatusMessage", this);
    }

    // Create the title container
    //-------------------------------------------------------------
    private Node createTitle()
    {
        HBox container = new HBox();
        container.setAlignment(Pos.CENTER);

        Text titleText = new Text(" Start A Session ");
        titleText.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titleText.setWrappingWidth(300);
        titleText.setTextAlignment(TextAlignment.CENTER);
        titleText.setFill(Color.DARKGREEN);
        container.getChildren().add(titleText);


        return container;
    }

    // Create the main form content
    //-------------------------------------------------------------
    private VBox createFormContent()
    {
        VBox vbox = new VBox(50);

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Text prompt = new Text("");
        prompt.setWrappingWidth(400);
        prompt.setTextAlignment(TextAlignment.CENTER);
        prompt.setFill(Color.BLACK);
        grid.add(prompt, 0, 0, 2, 1);

        Text startDateLabel = new Text(" Start Date : ");
        Font myFont = Font.font("Helvetica", FontWeight.BOLD, 12);
        startDateLabel.setFont(myFont);
        startDateLabel.setWrappingWidth(150);
        startDateLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(startDateLabel, 0, 1);

        startDate = new DatePicker(LocalDate.now());
        String pattern = "yyyy-MM-dd";
        StringConverter converter = new StringConverter<LocalDate>() {
            DateTimeFormatter dateFormatter =
                    DateTimeFormatter.ofPattern(pattern);
            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }
            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        };
        startDate.setConverter(converter);
        startDate.setPromptText(pattern.toLowerCase());
        startDate.setEditable(false);
        grid.add(startDate, 1, 1);

        Text startTimeLabel = new Text(" Start Time : ");
        startTimeLabel.setFont(myFont);
        startTimeLabel.setWrappingWidth(150);
        startTimeLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(startTimeLabel, 0, 2);

        startTime = new TextField();
        grid.add(startTime, 1, 2);



        Text endTimeLabel = new Text(" End Time : ");
        endTimeLabel.setFont(myFont);
        endTimeLabel.setWrappingWidth(150);
        endTimeLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(endTimeLabel, 0, 4);

        endTime = new TextField();
        grid.add(endTime, 1, 4);

        Text startCashLabel = new Text(" Starting Cash : ");
        startCashLabel.setFont(myFont);
        startCashLabel.setWrappingWidth(150);
        startCashLabel.setTextAlignment(TextAlignment.RIGHT);
        grid.add(startCashLabel, 0, 5);

        startCash = new TextField();
        UIUtils.limitToDigits(startCash);
        grid.add(startCash, 1, 5);

        HBox doneCont = new HBox(10);
        doneCont.setAlignment(Pos.CENTER);

        submitButton = new Button("Submit");
        submitButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        submitButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                clearErrorMessage();

                Properties props = new Properties();
                String startDateInput = startDate.getEditor().getText();
                String startTimeInput = startTime.getText();
                String endTimeInput = endTime.getText();
                String startCashInput = startCash.getText();

                //check that starting cash is not zero
                double numberStartingCash = 0;
                try {
                    numberStartingCash = Double.parseDouble(startCashInput);
                } catch(NumberFormatException exc) {
                    displayErrorMessage("Please enter a valid starting cash");
                }
                if(numberStartingCash <= 0){
                    displayErrorMessage("Starting cash cannot be negative or zero.");
                    return;
                }

                if(!UIUtils.validateTimeFormat(startTimeInput)) {
                    displayErrorMessage("Please enter a valid start time");
                    return;
                }
                if(!UIUtils.validateTimeFormat(endTimeInput)) {
                    displayErrorMessage("Please enter a valid end time");
                    return;
                }
                String[] startTime = startTimeInput.split(":");
                String[] endTime = endTimeInput.split(":");
                int startHours = Integer.parseInt(startTime[0]);
                int startMinutes = Integer.parseInt(startTime[1]);
                int endHours = Integer.parseInt(endTime[0]);
                int endMinutes = Integer.parseInt(endTime[1]);
                if((startHours > endHours || (startHours == endHours && startMinutes >= endMinutes))) {
                    displayErrorMessage("Start time should be before end time");
                    return;
                }
                props.setProperty("startDate",startDateInput);
                props.setProperty("startTime",startTimeInput);
                props.setProperty("endTime", endTimeInput);
                props.setProperty("startingCash",startCashInput);

                myModel.stateChangeRequest("SessionData", props);
            }
        });
        doneCont.getChildren().add(submitButton);



        doneButton = new Button("Back");
        doneButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        doneButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                clearErrorMessage();
                myModel.stateChangeRequest("CancelTransaction", null);
            }
        });
        doneCont.getChildren().add(doneButton);

        vbox.getChildren().add(grid);
        vbox.getChildren().add(doneCont);

        return vbox;
    }

    // Create the status log field
    //-------------------------------------------------------------
    protected MessageView createStatusLog(String initialMessage)
    {
        statusLog = new MessageView(initialMessage);

        return statusLog;
    }

    //-------------------------------------------------------------
    public void populateFields()
    {

    }

    /**
     * Update method
     */
    //---------------------------------------------------------
    public void updateState(String key, Object value)
    {

        if (key.equals("TransactionError") == true)
        {
            String val = (String)value;
            if ((val.startsWith("Err")) || (val.startsWith("ERR"))) {
                displayErrorMessage(val);
            }
            else {
                displayMessage(val);
            }
        }
    }

    /**
     * Display error message
     */
    //----------------------------------------------------------
    public void displayErrorMessage(String message)
    {
        statusLog.displayErrorMessage(message);
    }

    /**
     * Display info message
     */
    //----------------------------------------------------------
    public void displayMessage(String message)
    {
        statusLog.displayMessage(message);
    }

    /**
     * Clear error message
     */
    //----------------------------------------------------------
    public void clearErrorMessage()
    {
        statusLog.clearErrorMessage();
    }

}