package userinterface;

// system imports
import Utilities.UIUtils;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

import java.util.Properties;

// project imports
import impresario.IModel;
import model.Tree;
import model.TreeType;

public class CostScreenView extends View{

    protected TextField cost;
    protected Text typeDescription;
    protected TextArea notes;

    protected Button submitButton;
    protected Button doneButton;

    // For showing error message
    protected MessageView statusLog;


    public CostScreenView(IModel wsc)
    {
        super(wsc, "CostScreenView");

        // create a container for showing the contents
        VBox container = new VBox(10);
        container.setPadding(new Insets(15, 5, 5, 5));

        // create our GUI components, add them to this panel
        container.getChildren().add(createTitle());
        container.getChildren().add(createFormContent());

        // Error message area
        container.getChildren().add(createStatusLog("                                            "));

        getChildren().add(container);


        myModel.subscribe("TransactionError", this);
        populateFields();
    }

    protected void populateFields()
    {
        // treeType.setText((String)myModel.getState("treeType"));
        //	notes.setText((String)myModel.getState("Notes"));
        //	status.setValue((String)myModel.getState("Status"));
        cost.setText((String)myModel.getState("Cost"));
        //do something
    }

    private Node createTitle()
    {
        HBox container = new HBox();
        container.setAlignment(Pos.CENTER);

        Text titleText = new Text(" TROOP 209 TREE SALES SYSTEM ");
        titleText.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titleText.setWrappingWidth(300);
        titleText.setTextAlignment(TextAlignment.CENTER);
        titleText.setFill(Color.BLACK);
        container.getChildren().add(titleText);

        return container;
    }

    private VBox createFormContent()
    {
        VBox vbox = new VBox(10);

        TreeType treeType = (TreeType) myModel.getState("TreeType");
        Tree tree = (Tree) myModel.getState("Tree");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Text prompt = new Text("Cost Screen "); //add barcode here?
        prompt.setWrappingWidth(350);
        prompt.setTextAlignment(TextAlignment.CENTER);
        prompt.setFill(Color.BLACK);
        grid.add(prompt, 0, 0, 2, 1);

        typeDescription = new Text();
        Platform.runLater(() -> {
            typeDescription.setText((String) treeType.getState("typeDescription"));
        });

        grid.add(typeDescription, 0, 1);


        //tree cost
        Text costLabel = new Text(" Tree Cost : ");
        Font myFont = Font.font("Helvetica", FontWeight.BOLD, 12);
        costLabel.setFont(myFont);
        costLabel.setWrappingWidth(150);
        grid.add(costLabel, 0, 2);

        cost = new TextField();
        Platform.runLater(() -> {
            cost.setText((String) treeType.getState("cost"));
        });

        grid.add(cost, 0, 3);

        notes = new TextArea();
        Platform.runLater(() -> {
            notes.setText((String) tree.getState("Notes"));
        });
        UIUtils.limitLength(notes, 200);
        grid.add(notes, 0, 4);

        //Submit and Done button

        HBox doneCont = new HBox(10);
        doneCont.setAlignment(Pos.CENTER);

        submitButton = new Button("Submit");
        submitButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        submitButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                clearErrorMessage();

                Properties costProps = new Properties();
                Properties treeProps = new Properties();

                String costInput = cost.getText();
                if(costInput == null) {
                    displayErrorMessage("ERROR: Enter a cost");
                    return;
                }
                if(!UIUtils.validateCurrencyFormat(costInput)) {
                    displayErrorMessage("ERROR: Please enter a valid cost");
                    return;
                }

                String notesInput = notes.getText();

                costProps.setProperty("Cost",costInput);
                treeProps.setProperty("Notes", notesInput);


                //displayMessage("Tree Updated Successfully"); validation should come from model

                myModel.stateChangeRequest("NewCost", costProps);
                myModel.stateChangeRequest("NewNotes", treeProps);
                myModel.stateChangeRequest("CustomerInfoView", null);

            }
        });
        doneCont.getChildren().add(submitButton);

        doneButton = new Button("Back");
        doneButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        doneButton.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                clearErrorMessage();
                myModel.stateChangeRequest("CancelTransaction", null);
            }
        });
        doneCont.getChildren().add(doneButton);

        vbox.getChildren().add(grid);
        vbox.getChildren().add(doneCont);

        return vbox;
    }

    // Create the status log field
    //-------------------------------------------------------------
    protected MessageView createStatusLog(String initialMessage)
    {
        statusLog = new MessageView(initialMessage);

        return statusLog;
    }

    //-------------------------------------------------------------

    /**
     * Update method
     */
    //---------------------------------------------------------
    public void updateState(String key, Object value)
    {

        if (key.equals("TransactionError") == true)
        {
            String val = (String)value;
            if ((val.startsWith("Err")) || (val.startsWith("ERR"))) {
                displayErrorMessage(val);
            }
            else {
                displayMessage(val);
            }
        }
    }

    /**
     * Display error message
     */
    //----------------------------------------------------------
    public void displayErrorMessage(String message)
    {
        statusLog.displayErrorMessage(message);
    }

    /**
     * Display info message
     */
    //----------------------------------------------------------
    public void displayMessage(String message)
    {
        statusLog.displayMessage(message);
    }

    /**
     * Clear error message
     */
    //----------------------------------------------------------
    public void clearErrorMessage()
    {
        statusLog.clearErrorMessage();
    }

}

//---------------------------------------------------------------
//	Revision History:
//




