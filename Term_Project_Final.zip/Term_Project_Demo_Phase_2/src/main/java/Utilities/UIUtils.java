package Utilities;

import javafx.application.Platform;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputControl;

public class UIUtils {
    //restricts textfield so that user can only enter digits
    public static void limitToDigits(TextField restrictedField) {
        restrictedField.textProperty().addListener((obs, oldVal, newVal) -> {
            int position = restrictedField.getCaretPosition();
            if (!newVal.matches("\\d*")) {
                Platform.runLater(() -> {
                    restrictedField.setText(newVal.replaceAll("[^\\d]", ""));
                    restrictedField.positionCaret(position);
                });
            }
        });
    }
    //restricts textfield so that user can only enter characters up to "length"
    public static void limitLength(TextInputControl restrictedField, int length) {
        restrictedField.textProperty().addListener((obs, oldVal, newVal) -> {
            int position = restrictedField.getCaretPosition();
            if (newVal.length() > length) {
                Platform.runLater(() -> {
                    restrictedField.setText(oldVal);
                    restrictedField.positionCaret(position);
                });
            }
        });
    }

    public static boolean validateTimeFormat(String time) {
        //time must have a colon
        if(!time.contains(":")) {
            return false;
        }
        String[] split = time.split(":");
        String minutes;
        String hours;
        try {
            hours = split[0];
            minutes = split[1];
        } catch(ArrayIndexOutOfBoundsException e) {
            return false;
        }
        //hours should have either 1 or 2 digits, minutes should always have two digits, there should be exactly two
        //values in the split array
        if((hours.length() != 1 && hours.length() != 2) || minutes.length() != 2 || split.length != 2) {
            return false;
        }
        int intHours = 0;
        int intMinutes = 0;
        //if integer.parseint fails then it isn't a number
        try {
            intHours = Integer.parseInt(hours);
            intMinutes = Integer.parseInt(minutes);
        } catch(NumberFormatException e) {
            return false;
        }
        //24 hour time
        return intHours < 24 && intHours >= 0 && intMinutes < 60 && intMinutes >= 0;
    }

    public static boolean validateCurrencyFormat(String currency) {
        if(!currency.contains(".")) {
            return false;
        }
        String[] split = currency.split("\\.");
        String dollars;
        String cents;
        try {
            dollars = split[0];
            cents = split[1];
        } catch(ArrayIndexOutOfBoundsException e) {
            return false;
        }
        if(cents.length() != 2 || split.length != 2) {
            return false;
        }
        int intDollars;
        int intCents;
        try {
            intDollars = Integer.parseInt(dollars);
            intCents = Integer.parseInt(cents);
        } catch(NumberFormatException e) {
            return false;
        }
        return intDollars >= 0 && intCents >= 0;
    }
}