// specify the package
package model;

// system imports
import javafx.stage.Stage;
import javafx.scene.Scene;
import java.util.Properties;
import java.util.Vector;

// project imports
import event.Event;
import exception.InvalidPrimaryKeyException;

import userinterface.View;
import userinterface.ViewFactory;

/** The class containing the WithdrawTransaction for the ATM application */
//==============================================================
public class StartSessionTransaction extends Transaction
{
    private Session mySession; // needed for GUI only

    // GUI Components

    private String transactionErrorMessage = "";
    private ScoutCollection scoutCollection;
    private Scout selectedScout;
    private ScoutCollection selectedScoutCollection;

    private Shift myShift;

    private String sentSessionId;

    private String shiftUpdateStatusMessage = "";
    /**
     * Constructor for this class.
     *
     *
     */
    //----------------------------------------------------------
    public StartSessionTransaction()
            throws Exception
    {
        super();
        System.out.println("Creating start session transaction");
        scoutCollection = new ScoutCollection();
        selectedScoutCollection = new ScoutCollection();
        System.out.println("Done creating start session transaction");
    }

    //----------------------------------------------------------
    protected void setDependencies()
    {
        dependencies = new Properties();
        //dependencies.setProperty("SessionData", "UpdateStatusMessage");
        dependencies.setProperty("OK", "CancelTransaction");
        dependencies.setProperty("StartShift","ShiftUpdateMessage");
        dependencies.setProperty("ShiftData", "ShiftUpdateStatusMessage");
        dependencies.setProperty("ScoutSelected", "ShiftUpdateStatusMessage");
        dependencies.setProperty("CancelStartSession","CancelTransaction");

        myRegistry.setDependencies(dependencies);
    }

    public void processTransaction(Properties props) {

        String sentSessionId = (String)props.getProperty("Id");
        System.out.println(props.getProperty("endDate"));
        try
        {
            Session s = new Session(sentSessionId);
            transactionErrorMessage = "ERROR: Session with Id: " + sentSessionId + " already exists";
        }
        catch (Exception ex) {
            mySession = new Session(props);
            mySession.update();
            transactionErrorMessage = (String) mySession.getState("UpdateStatusMessage");

        }
    }

    public void processShift(Properties props) {
        String sessionId = (String) mySession.getState("Id");
        String scoutId = (String) selectedScout.getState("scoutId");
        props.setProperty("scoutId", scoutId);
        props.setProperty("sessionId", sessionId);
        //props.setProperty("endTime", "");
        myShift = new Shift(props);

        //myShift.update();

        myShift = new Shift(props);
        myShift.setOldFlag(false);
        myShift.update();
        shiftUpdateStatusMessage = "Scout added to shift!";
        //test
        /*try
        {
            Shift s = new Shift(sessionId);
            shiftUpdateStatusMessage = "ERROR: Shift with Session Id: " + sessionId + " already exists";
        }
        catch (Exception ex) {
            myShift = new Shift(props);
            myShift.setOldFlag(false);
            myShift.update();
            shiftUpdateStatusMessage = "Scout added to shift!";
        }*/
       // createAndShowScoutCollectionView(); // do for return to scout collection button
    }

    //-----------------------------------------------------------
    public Object getState(String key)
    {
        if (key.equals("TransactionError") == true)
        {
            return transactionErrorMessage;
        }
        else
        if (key.equals("ScoutList") == true)
        {
            return scoutCollection;
        }
        else
        if (key.equals("SelectedScoutList") == true)
        {
            return selectedScoutCollection;
        }
        else
        if (key.equals("ShiftUpdateStatusMessage") == true)
        {
            return shiftUpdateStatusMessage;
        }
        return null;
    }

    //-----------------------------------------------------------
    public void stateChangeRequest(String key, Object value)
    {
        if (key.equals("DoYourJob") == true)
        {
            doYourJob();
        }
        else
        if (key.equals("SessionData") == true) {
            processTransaction((Properties)value);
            System.out.println("Liz was here 1");
            try {
                scoutCollection.findAllScouts();
                createAndShowScoutCollectionView();
            } catch (Exception ex) {
                System.out.println("Liz was here 1 - Exception thrown");
                System.out.println(ex);
                ex.printStackTrace();
                transactionErrorMessage = "ERROR: No scouts found!";
            }
        } else if (key.equals("ScoutSelected") == true)
        {
            selectedScout = scoutCollection.retrieveByTroopId((String)value);
            if (selectedScoutCollection.isScoutInCollection(selectedScout) == false) {
                selectedScoutCollection.addSelectedScout(selectedScout);
                createAndShowShiftInfoEntryView();
            }
            else
            {
                shiftUpdateStatusMessage = "ERROR: Selected scout already in shift!";
            }

        } else if (key.equals("ShiftData") == true)
        {
            processShift((Properties)value);

        } else if (key.equals("AddAnotherScout") == true)
        {
            createAndShowScoutCollectionView();
        }

        myRegistry.updateSubscribers(key, this);
    }

    /**
     * Create the view of this class. And then the super-class calls
     * swapToView() to display the view in the stage
     */
    //------------------------------------------------------
    protected Scene createView()
    {
        System.out.println("Liz was here - create session info view");
        Scene currentScene = myViews.get("SessionInfoView");

        if (currentScene == null)
        {
            // create our new view
            View newView = ViewFactory.createView("SessionInfoView", this);
            currentScene = new Scene(newView);
            myViews.put("SessionInfoView", currentScene);

            return currentScene;
        }
        else
        {
            return currentScene;
        }
    }

    //------------------------------------------------------
    protected void createAndShowScoutCollectionView()
    {
        System.out.println("Liz was here 2");
        View newView = ViewFactory.createView("ScoutCollectionView", this);
        Scene newScene = new Scene(newView);

        myViews.put("ScoutCollectionView", newScene);

        swapToView(newScene);
    }

    protected void createAndShowShiftInfoEntryView()
    {
        System.out.println("Liz was here 3");
        shiftUpdateStatusMessage = "";
        View newView = ViewFactory.createView("ShiftInfoEntryView", this);
        Scene newScene = new Scene(newView);

        myViews.put("ShiftInfoEntryView", newScene);

        swapToView(newScene);
    }
}
